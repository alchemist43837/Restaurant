<?php

    class DbJSON extends DB
    {
        public function guardarUsuario(Usuario $usuario)
        {
           //...
        }

        public function buscamePorEmail($email)
        {
            //..
        }

        public function traeTodaLaBase()
        {
            //...
        }
    }