<?php

$myArray = ["Ford","Chevrolet","Fiat"];

var_dump($myArray);

$myArray2['Ford'] =  "Fiesta";
$myArray2['Chevrolet'] =  "Corsa";
$myArray2['Fiat'] =  "Corsa";

var_dump($myArray2);

$miAuto['marca'] = "Fiat";
$miAuto['anio'] = "1993";
$miAuto['color'] = "Rojo";

echo $miAuto['color'];

foreach ($miAuto as $key => $value) {

}

 ?>
