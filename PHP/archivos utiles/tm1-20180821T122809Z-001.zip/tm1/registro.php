<!DOCTYPE html>
<html>
<head>
  <meta charset="utf-8">
  <link rel="stylesheet" href="css/styles.css">
  <link rel="stylesheet" href="css/registro.css">
  <title>Formularios</title>
</head>
<body>

  <div class="contenedor-principal">

    <p class="centrar">
      <a href="index.html">
        <img id="logo" src="images/logo.png" alt="logo Digital Movies">
      </a>
    </p>

    <h1 class="centrar">Registrate en Digital Movies</h1>
    <form action="" method="post">

    <label class="etiqueta" for="nombreDelUsuario">Nombre:</label>

    <input type="text" id="nombreDelUsuario" placeholder="Ingrese su nombre" required name="userName"><span> *</span>

    <br><br>

    <label class="etiqueta" for="nombreDelUsuario">Edad:</label>
      <input  id="nombreDelUsuario" type="number" name="userAge" min="18">

    <br><br>

    <label class="etiqueta">Teléfono de contacto:</label>
    <input type="tel" placeholder="011-111-1111" name="userPhone">

    <br><br>

    <label class="etiqueta">Email:</label>

    <input type="email" required name="userMail"><span> *</span>

    <br><br>

    <label class="etiqueta" for="">Sitio web:</label>
    <input type="url" required name="userSite">

    <br><br>

    <label class="etiqueta" for="">Contraseña</label>

    <input type="password" name="userPass" maxlength="8"><span> *</span>

    <br><br>

    <label class="etiqueta" for="avatar">Subi tu Avatar:</label>
    <input type="file" id="avatar" name="userPhoto">

    <br><br>

    <label class="etiqueta">Género</label>
      <label><input type="radio" name="userGender" value="m">Masculino</label>
      <label><input type="radio" name="userGender" value="f">Femenino</label>

    <br><br>

    <label class="etiqueta">Estado Civil:</label>
      <label><input type="radio" name="userCivilStatus" value="soltero">Soltero</label>
      <label><input type="radio" name="userCivilStatus" value="casado">Casado</label>
      <label><input type="radio" name="userCivilStatus" value="viudo">Viudo</label>

    <br><br>

    <label class="etiqueta" for="">Pasatiempos</label>
      <label><input type="checkbox" name="userHobbies[]" value="pasear">Pasear</label>
      <label><input type="checkbox" name="userHobbies[]" value="tennis">Jugar al Tennis</label>
      <label><input type="checkbox" name="userHobbies[]" value="mate">Tomar mate</label>


    <br><br>

    <label class="etiqueta">Comentarios:</label>
    <textarea name="userComments" placeholder="Estoy comentando"></textarea>

    <br><br>

    <label class="etiqueta">Pais de Origen</label>
    <select name="userCountry">
      <option>Seleccione un Pais</option>
      <option>Argentina</option>
      <option>Brasil</option>
      <option>Bolivia</option>
      <option>Colombia</option>
      <option>Chile</option>
      <option>Peru</option>
    </select>

    <br><br>
    <div class="centrar">
      <button type="reset">Borrar</button>
      <button type="submit">Registrate</button>
    </div>


    </form>
  </div>
</body>
</html>
