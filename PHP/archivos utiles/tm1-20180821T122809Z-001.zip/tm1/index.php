<?php

//Generos
//$generos = ['Acción','Comedia','Terror','Suspenso','Drama','Aventura','Triller'];
$generos = [
  ['nombre' => 'Comedia', 'url' => 'comedia.php'],
  ['nombre' => 'Accion', 'url' => 'accion.php'],
  ['nombre' => 'Terror', 'url' => 'terror.php'],
  ['nombre' => 'Suspenso', 'url' => 'suspenso.php'],
  ['nombre' => 'Drama', 'url' => 'drama.php'],
  ['nombre' => 'Aventura', 'url' => 'aventura.php'],
  ['nombre' => 'Romance', 'url' => 'romance.php'],
  ['nombre' => 'Triller', 'url' => 'triller.php']

];


//Title
$title = "Digital Movies - Tus películas favoritas ​";

//h1
$titulo = "​Películas del mundo";

//Logo
$logo = "images/logo.png";

//h2
$segTitulo = "Peliculas Disponibles";

//Login
$logueado = true;

//Duracion Pelicula
$duracion = 120;
$duracion = $duracion / 60;

//IMAGEN ME GUSTA
$meGusta = true;

//IMAGEN ESTRENO
$estreno = 3;

//IMAGEN 3D
$tresd = true;

//ESTRELLA
$stars = '<img class="ranking" src="images/star.png" alt="">';

 ?>


<!DOCTYPE html>
<html lang="en" dir="ltr">
  <head>
    <meta charset="utf-8">
    <title><?php echo $title; ?></title>
    <link href="https://fonts.googleapis.com/css?family=Modern+Antiqua" rel="stylesheet">
    <link rel="stylesheet" href="css/styles.css">
  </head>
  <body>

  <div class="contenedor-principal">
      <?php
        include('header.php');
      ?>


      <h2><?php echo $segTitulo; ?></h2>

    <div class="contenedor-pelis">
      <div class="items">
        <img class="poster" src="images/avatar.jpg" alt="">
        <div class="detalle">
          <label>Avatar (2002)</label>
          <label>Acción</label>
          <label>Duración: <?php echo $duracion; ?> Horas </label>
          <label>Rating: 5</label>
          <label> <?php echo str_repeat($stars, 3); ?>
            <img class="ranking" src="images/starblack.png" alt=""> </label>

            <label>
              <?php
                  if ($meGusta) {
                    echo '<img class="ranking" src="images/thumb-up-icon.png" alt="">';
                  }
                  else{
                    echo '<img class="ranking" src="images/thumb-down-icon.png" alt="">';
                  }
               ?>

            </label>
             <?php
              if ($estreno < 4) {
                echo '<img class="estreno" src="images/estreno3.png" alt="">';
              }
             ?>
            <img class="taquillera" src="images/ticket.png" alt="">
             <?php
                if ($tresd) {
                  echo '<img class="tresd" src="images/anteojos-3d.png" alt="">';
                }
             ?>
        </div>
      </div>

      <div class="items">
        <img  class="poster" src="images/avengers.jpg" alt="">
        <div class="detalle">
          <label>Avengers (May 2018)</label>
          <label>Acción</label>
          <label>Duración: <?php echo $duracion; ?> Horas </label>
          <label>Rating: 5</label>
          <label> <?php echo str_repeat($stars, 3); ?>
            <img class="ranking" src="images/starblack.png" alt=""> </label>

            <label>
              <?php
                  if ($meGusta) {
                    echo '<img class="ranking" src="images/thumb-up-icon.png" alt="">';
                  }
                  else{
                    echo '<img class="ranking" src="images/thumb-down-icon.png" alt="">';
                  }
               ?>

            </label>
             <?php
              if ($estreno < 4) {
                echo '<img class="estreno" src="images/estreno3.png" alt="">';
              }
             ?>
            <img class="taquillera" src="images/ticket.png" alt="">
             <?php
                if ($tresd) {
                  echo '<img class="tresd" src="images/anteojos-3d.png" alt="">';
                }
             ?>
        </div>
      </div>

      <div class="items">
        <img  class="poster" src="images/moana.jpg" alt="">
        <div class="detalle">
          <label>Moana (Mar 2016)</label>
          <label>Animadas</label>
          <label>Duración: <?php echo $duracion; ?> Horas </label>
          <label>Rating: 5</label>
          <label> <?php echo str_repeat($stars, 3); ?>
            <img class="ranking" src="images/starblack.png" alt=""> </label>

            <label>
              <?php
                  if ($meGusta) {
                    echo '<img class="ranking" src="images/thumb-up-icon.png" alt="">';
                  }
                  else{
                    echo '<img class="ranking" src="images/thumb-down-icon.png" alt="">';
                  }
               ?>

            </label>
             <?php
              if ($estreno < 4) {
                echo '<img class="estreno" src="images/estreno3.png" alt="">';
              }
             ?>
            <img class="taquillera" src="images/ticket.png" alt="">
             <?php
                if ($tresd) {
                  echo '<img class="tresd" src="images/anteojos-3d.png" alt="">';
                }
             ?>
        </div>
      </div>

      <div class="items">
        <img  class="poster" src="images/rogueone.jpg" alt="">
        <div class="detalle">
          <label>Rogue One (Dic 2017)</label>
          <label>Acción</label>
          <label>Duración: <?php echo $duracion; ?> Horas </label>
          <label>Rating: 5</label>
          <label> <?php echo str_repeat($stars, 3); ?>
            <img class="ranking" src="images/starblack.png" alt=""> </label>

            <label>
              <?php
                  if ($meGusta) {
                    echo '<img class="ranking" src="images/thumb-up-icon.png" alt="">';
                  }
                  else{
                    echo '<img class="ranking" src="images/thumb-down-icon.png" alt="">';
                  }
               ?>

            </label>
             <?php
              if ($estreno < 4) {
                echo '<img class="estreno" src="images/estreno3.png" alt="">';
              }
             ?>
            <img class="taquillera" src="images/ticket.png" alt="">
             <?php
                if ($tresd) {
                  echo '<img class="tresd" src="images/anteojos-3d.png" alt="">';
                }
             ?>
        </div>
      </div>

      <div class="items">
        <img  class="poster" src="images/titanic.jpg" alt="">
        <div class="detalle">
          <label>Titanic (Abr 1995)</label>
          <label>Romance</label>
          <label>Duración: <?php echo $duracion; ?> Horas </label>
          <label>Rating: 5</label>
          <label> <?php echo str_repeat($stars, 3); ?>
            <img class="ranking" src="images/starblack.png" alt=""> </label>

            <label>
              <?php
                  if ($meGusta) {
                    echo '<img class="ranking" src="images/thumb-up-icon.png" alt="">';
                  }
                  else{
                    echo '<img class="ranking" src="images/thumb-down-icon.png" alt="">';
                  }
               ?>

            </label>
             <?php
              if ($estreno < 4) {
                echo '<img class="estreno" src="images/estreno3.png" alt="">';
              }
             ?>
            <img class="taquillera" src="images/ticket.png" alt="">
             <?php
                if ($tresd) {
                  echo '<img class="tresd" src="images/anteojos-3d.png" alt="">';
                }
             ?>
        </div>
      </div>

      <div class="items">
        <img  class="poster" src="images/dragonball.jpg" alt="">
        <div class="detalle">
          <label>Drangon Ball Z (Jul 2005)</label>
          <label>Animada</label>
          <label>Duración: <?php echo $duracion; ?> Horas </label>
          <label>Rating: 5</label>
          <label> <?php echo str_repeat($stars, 3); ?>
            <img class="ranking" src="images/starblack.png" alt=""> </label>

            <label>
              <?php
                  if ($meGusta) {
                    echo '<img class="ranking" src="images/thumb-up-icon.png" alt="">';
                  }
                  else{
                    echo '<img class="ranking" src="images/thumb-down-icon.png" alt="">';
                  }
               ?>

            </label>
             <?php
              if ($estreno < 4) {
                echo '<img class="estreno" src="images/estreno3.png" alt="">';
              }
             ?>
            <img class="taquillera" src="images/ticket.png" alt="">
             <?php
                if ($tresd) {
                  echo '<img class="tresd" src="images/anteojos-3d.png" alt="">';
                }
             ?>
        </div>
      </div>

      <div class="items">
        <img  class="poster" src="images/emoji.jpg" alt="">
        <div class="detalle">
          <label>Emoji (Oct 2016)</label>
          <label>Animada</label>
          <label>Duración: <?php echo $duracion; ?> Horas </label>
          <label>Rating: 5</label>
          <label> <?php echo str_repeat($stars, 3); ?>
            <img class="ranking" src="images/starblack.png" alt=""> </label>

            <label>
              <?php
                  if ($meGusta) {
                    echo '<img class="ranking" src="images/thumb-up-icon.png" alt="">';
                  }
                  else{
                    echo '<img class="ranking" src="images/thumb-down-icon.png" alt="">';
                  }
               ?>

            </label>
             <?php
              if ($estreno < 4) {
                echo '<img class="estreno" src="images/estreno3.png" alt="">';
              }
             ?>
            <img class="taquillera" src="images/ticket.png" alt="">
             <?php
                if ($tresd) {
                  echo '<img class="tresd" src="images/anteojos-3d.png" alt="">';
                }
             ?>
        </div>
      </div>

    </div>

<?php
  include('footer.php');
 ?>


  </div>
  </body>
</html>
