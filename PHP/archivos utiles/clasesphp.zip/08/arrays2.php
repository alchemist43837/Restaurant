<pre>
<?php
  $notas = [];

  $notas['Julia'] = [
                      'Tri1' => 4,
                      'Tri2' => 7,
                      'Tri3' => 5
                  ];

  $notas['Diego'] = [ 'Tri1' =>10, 'Tri2' =>8, 'Tri3' =>6 ];

  //var_dump($notas);
//sin el nombre del alumno
// foreach ($notas as $evaluaciones) {
//   $unidas = implode(', ', $evaluaciones);
//   echo '<br>Las notas son: '.$unidas;
// }




//con el nombre del alumno o la posicion
foreach ($notas as $nombre => $evaluaciones) {
  $unidas = implode(', ', $evaluaciones);
  echo '<br>Las notas de: '.$nombre.' son: '.$unidas;
}
//echo 'La nota que quiere Diego es: '.$notas[1][1];




 ?>
