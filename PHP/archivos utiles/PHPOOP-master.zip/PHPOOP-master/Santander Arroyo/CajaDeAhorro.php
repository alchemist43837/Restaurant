<?php

class CajaDeAhorro extends Cuenta{
    
}
