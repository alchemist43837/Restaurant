<?php

$notas = [];

$notas['Julia'] = [ 'Tri1' => 6,
                    'Tri2' => 7,
                    'Tri3' => 5 ];

$notas['Diego'] = [ 'Tri1' =>10, 'Tri2' =>8, 'Tri3' =>6 ];

$notas['Juan'] = [ 'Tri1' =>10, 'Tri2' =>8, 'Tri3' =>6 ];

$notas['Roberto'] = [ 'Tri1' =>10, 'Tri2' =>8, 'Tri3' =>6 ];

$notas['Emilio'] = [ 'Tri1' =>10, 'Tri2' =>8, 'Tri3' =>6 ];

$notas['Juan Cruz'] = [ 'Tri1' =>10, 'Tri2' =>8, 'Tri3' =>6 ];

 ?>
