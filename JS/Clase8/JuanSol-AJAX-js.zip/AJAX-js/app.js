window.onload = function() {

	var peliculas
				var ul = document.querySelector('ul')


	function actualizar () {
		fetch("http://localhost:8888/AJAX-js/get.php")
		.then(function (response) {
			return response.json();
		})
		.then(function (data) {
			console.log('estoy en actualizar')
			var numero = document.querySelector('.numero')
			numero.innerText = data.length
			data.forEach(function(element, index) {
				var li = document.createElement('li')
				li.innerText = element.title
				ul.append(li)
			})

		})
		.catch(function (error) {
			console.log("The error was: " + error);
		})
	}


	// actualizar()

	form = document.querySelector('form')
	formElements = form.elements


	


	form.addEventListener('submit', function (event) {

		var campos = {
			title: formElements.title.value,
			rating: formElements.ratin.value,
			awards: formElements.awards.value,
			release_date: formElements.release_date.value
		}

		var datosDelFormulario = new FormData();
		datosDelFormulario.append('datos', JSON.stringify(campos))

		fetch("http://localhost:8888/AJAX-js/post.php", {
			method: 'POST',
			body: datosDelFormulario
			}
		)
		.then(function (response) {
			return response.text();
		})
		.then(function (data) {
			console.log(data)
		actualizar()
			
		})


		while( ul.firstChild ){
 			ul.removeChild( ul.firstChild );
		}

		// setTimeout(actualizar, 2000);



		event.preventDefault()

		})


}